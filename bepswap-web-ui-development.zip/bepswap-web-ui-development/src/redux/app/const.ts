export const MAX_VALUE = 100;
export const MIN_VALUE = 0;
