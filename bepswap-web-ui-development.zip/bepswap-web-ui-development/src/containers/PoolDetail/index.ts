import PoolDetail from './PoolDetail';

export default PoolDetail;
