import PoolView from './PoolView';

export default PoolView;
