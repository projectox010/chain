/* eslint-disable quotes */
export const data = [
  {
    title: 'MIDGARD EXPLORER',
    description: 'Explore Midgard API Endpoints',
    info: 'midgard-explorer.herokuapp.com',
    link: 'http://midgard-explorer.herokuapp.com/',
  },
  {
    title: 'MIDGARD API SPEC',
    description: "Explore Midgard's Design Spec",
    info: 'Google Doc',
    link: 'https://docs.google.com/document/u/1/d/1ZoJQKvyATQekFbWMk_rqX96K9BSmCArh9e-A_g66wDQ/mobilebasic#heading=h.xymrivoqt1ra',
  },
];
