import ApiDocView from './ApiDocView';

export default ApiDocView;
