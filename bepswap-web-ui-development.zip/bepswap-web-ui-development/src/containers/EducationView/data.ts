export const data = [
  {
    title: 'OFFICIAL DOCS',
    description: 'The Official THORChain Documentation.',
    info: 'docs.thorchain.org',
    link: 'https://docs.thorchain.org',
  },
  {
    title: 'REBASE FOUNDATION',
    description: 'An Easy-To-Understand Overview of THORChain.',
    info: 'rebase.foundation/network/thorchain',
    link: 'https://rebase.foundation/network/thorchain/',
  },
];
