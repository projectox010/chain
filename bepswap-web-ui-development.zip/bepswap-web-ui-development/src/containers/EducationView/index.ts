import EducationView from './EducationView';

export default EducationView;
