import TransactionView from './TransactionView';

export default TransactionView;
