export type TxFilter = {
  offset?: number;
  limit?: number;
  address?: string;
  txId?: string;
  asset?: string;
  type?: string;
};
