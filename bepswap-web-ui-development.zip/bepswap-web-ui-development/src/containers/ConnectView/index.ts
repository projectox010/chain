import ConnectView from './ConnectView';

export default ConnectView;
