import Page500 from './500';

export default Page500;
