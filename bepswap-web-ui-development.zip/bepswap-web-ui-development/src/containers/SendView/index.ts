import SendView from './SendView';

export default SendView;
