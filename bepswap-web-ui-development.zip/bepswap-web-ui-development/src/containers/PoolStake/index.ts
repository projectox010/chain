import PoolStake from './PoolStake';

export default PoolStake;
