export const data = [
  {
    title: 'THORCHAIN.NET',
    description: 'A lightweight, Open-Source THORChain Explorer.',
    info: 'thorchain.net',
    link: 'https://thorchain.net/',
  },
  {
    title: 'THORCHAIN Block Explorer',
    description: 'Official Block Explorer Built by ViewBlock.',
    info: 'viewblock.io/thorchain',
    link: 'https://viewblock.io/thorchain',
  },
  {
    title: 'Delphi Digital Dashboard',
    description: 'A Dashboard Built For THORChain By The Delphi Digital Team',
    info: 'defi.delphidigital.io/thorchain',
    link: 'https://defi.delphidigital.io/thorchain',
  },
];
