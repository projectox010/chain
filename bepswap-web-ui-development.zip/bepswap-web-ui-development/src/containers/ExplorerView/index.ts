import ExplorerView from './ExplorerView';

export default ExplorerView;
