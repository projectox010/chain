import FaqsView from './FaqsView';

export default FaqsView;
