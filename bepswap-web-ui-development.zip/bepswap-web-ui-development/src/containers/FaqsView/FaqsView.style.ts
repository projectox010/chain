import styled from 'styled-components';

import ContentView from 'components/utility/contentView';

export const ContentWrapper = styled(ContentView)`
  & > .ant-row {
    display: flex;
  }
`;
