export enum SwapSendView {
  DETAIL = 'detail',
  SEND = 'send',
}
