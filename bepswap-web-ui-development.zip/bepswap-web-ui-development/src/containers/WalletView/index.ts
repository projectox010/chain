import WalletView from './WalletView';

export default WalletView;
