import StatisticsView from './StatisticsView';

export default StatisticsView;
