import ToolsView from './ToolsView';

export default ToolsView;
