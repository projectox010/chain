export const getAppContainer = () => {
  return document.getElementById('app-global') as HTMLElement;
};
