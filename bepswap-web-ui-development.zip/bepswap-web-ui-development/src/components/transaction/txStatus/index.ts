import TxStatus from './txStatus';

export default TxStatus;
