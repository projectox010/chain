import TxInfo from './txInfo';

export default TxInfo;
