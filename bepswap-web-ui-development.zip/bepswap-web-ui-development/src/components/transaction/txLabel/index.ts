import TxLabel from './txLabel';

export default TxLabel;
