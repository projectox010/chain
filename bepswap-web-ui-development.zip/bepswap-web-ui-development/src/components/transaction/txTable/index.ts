import TxTable from './txTable';

export default TxTable;
