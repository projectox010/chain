import Chart from './chart';

export default Chart;
