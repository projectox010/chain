import Tabs from './tabs';

export default Tabs;
