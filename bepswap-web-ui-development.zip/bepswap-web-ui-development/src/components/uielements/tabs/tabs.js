import { Tabs } from 'antd';

import { StyledTab } from './tabs.style';

export default StyledTab(Tabs);
