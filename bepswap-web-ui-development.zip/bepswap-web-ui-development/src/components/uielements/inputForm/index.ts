import InputForm from './inputForm';

export default InputForm;
