export type InputNumberWrapperSize = 'small' | 'default' | 'large';
export type InputNumberWrapperColor =
  | 'primary'
  | 'success'
  | 'warning'
  | 'error';
