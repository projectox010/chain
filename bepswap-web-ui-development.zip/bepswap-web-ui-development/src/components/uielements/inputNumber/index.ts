import InputNumber from './inputNumber';

export default InputNumber;
