import FilterMenu from './filterMenu';

export default FilterMenu;
