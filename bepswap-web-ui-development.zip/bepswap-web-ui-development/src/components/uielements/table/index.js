import Table from './table';

export default Table;
