import ThemeSwitch from './themeSwitch';

export default ThemeSwitch;
