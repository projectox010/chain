import StatusGroup from './statusGroup';

export default StatusGroup;
