import Trend from './trend';

export default Trend;
