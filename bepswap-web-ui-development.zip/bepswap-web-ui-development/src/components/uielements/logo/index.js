import Logo from './logo';

export default Logo;
