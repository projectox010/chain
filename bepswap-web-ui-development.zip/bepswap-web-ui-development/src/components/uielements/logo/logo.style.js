import styled from 'styled-components';

export const LogoWrapper = styled.div`
  display: block;
`;
