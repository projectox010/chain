import TooltipIcon from './tooltipIcon';

export default TooltipIcon;
