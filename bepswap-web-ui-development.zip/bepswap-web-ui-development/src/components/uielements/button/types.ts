export type ButtonSize = 'small' | 'normal' | 'big';
export type ButtonColor = 'primary' | 'success' | 'warning' | 'error';
export type ButtonWeight = 'normal' | 'bold' | '500';
export type ButtonType = 'normal' | 'default' | 'outline' | 'ghost';
export type ButtonRound = 'true' | 'false';
