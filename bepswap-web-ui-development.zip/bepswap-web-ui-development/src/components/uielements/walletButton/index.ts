import WalletButton from './walletButton';

export default WalletButton;
