import styled from 'styled-components';

export const FormGroupWrapper = styled.div`
  display: flex;
  flex-direction: column;
`;
