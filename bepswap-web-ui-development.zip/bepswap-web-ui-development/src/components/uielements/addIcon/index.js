import AddIcon from './addIcon';

export default AddIcon;
