import ContentTitle from './contentTitle';

export default ContentTitle;
