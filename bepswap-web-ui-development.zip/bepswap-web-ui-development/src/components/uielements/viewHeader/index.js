import ViewHeader from './viewHeader';

export default ViewHeader;
