import PanelHeader from './panelHeader';

export default PanelHeader;
