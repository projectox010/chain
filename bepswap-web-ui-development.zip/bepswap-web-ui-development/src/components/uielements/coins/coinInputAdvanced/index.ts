import { CoinInputAdvanced } from './coinInputAdvanced';

export default CoinInputAdvanced;
