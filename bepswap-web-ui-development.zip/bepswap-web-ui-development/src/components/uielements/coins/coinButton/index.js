import CoinButton from './coinButton';

export default CoinButton;
