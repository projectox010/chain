import CoinCard from './coinCard';

export default CoinCard;
