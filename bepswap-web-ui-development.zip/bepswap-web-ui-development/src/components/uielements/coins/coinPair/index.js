import CoinPair from './coinPair';

export default CoinPair;
