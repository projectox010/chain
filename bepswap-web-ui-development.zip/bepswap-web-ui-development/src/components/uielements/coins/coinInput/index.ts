import CoinInput from './coinInput';

export default CoinInput;
