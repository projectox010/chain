import CoinIcon from './coinIcon';

export default CoinIcon;
