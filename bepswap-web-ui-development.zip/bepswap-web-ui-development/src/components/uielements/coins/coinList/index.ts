import { CoinList } from './coinList';

export default CoinList;
