import CoinData from './coinData';

export default CoinData;
