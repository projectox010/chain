import Coin from './coin';

export default Coin;
