export type CoinSize = 'small' | 'big';
