import DynamicCoin from './dynamicCoin';

export default DynamicCoin;
