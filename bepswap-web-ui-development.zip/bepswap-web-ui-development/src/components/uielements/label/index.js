import Label from './label';

export default Label;
