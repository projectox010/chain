import Collapse from './collapse';

export default Collapse;
