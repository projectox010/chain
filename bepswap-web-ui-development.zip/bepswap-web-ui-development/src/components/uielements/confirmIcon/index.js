import ConfirmIcon from './confirmIcon';

export default ConfirmIcon;
