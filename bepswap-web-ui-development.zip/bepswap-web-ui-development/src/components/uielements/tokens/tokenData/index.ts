import TokenData from './tokenData';

export default TokenData;
