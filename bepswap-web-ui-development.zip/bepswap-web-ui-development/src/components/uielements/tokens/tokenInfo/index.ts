import TokenInfo from './tokenInfo';

export default TokenInfo;
