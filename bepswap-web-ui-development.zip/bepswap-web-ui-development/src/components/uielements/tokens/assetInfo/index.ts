import AssetInfo from './assetInfo';

export default AssetInfo;
