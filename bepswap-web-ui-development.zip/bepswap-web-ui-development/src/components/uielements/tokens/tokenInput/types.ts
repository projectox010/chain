export type TokenInputProps = {
  disabled?: boolean;
  'data-test'?: string;
};
