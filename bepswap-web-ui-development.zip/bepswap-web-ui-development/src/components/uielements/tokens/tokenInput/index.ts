import TokenInput from './tokenInput';

export default TokenInput;
