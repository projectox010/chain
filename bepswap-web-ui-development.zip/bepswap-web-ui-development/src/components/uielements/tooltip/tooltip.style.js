import { Popover } from 'antd';
import styled from 'styled-components';

export const TooltipWrapper = styled(Popover)`
  display: block;
`;
