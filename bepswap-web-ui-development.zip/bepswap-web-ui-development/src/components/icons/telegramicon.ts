import { ReactComponent as TelegramIcon } from 'assets/SVG/telegram.svg';

export { TelegramIcon };
