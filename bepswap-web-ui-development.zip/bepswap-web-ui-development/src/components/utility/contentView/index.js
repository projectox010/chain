import ContentView from './contentView';

export default ContentView;
