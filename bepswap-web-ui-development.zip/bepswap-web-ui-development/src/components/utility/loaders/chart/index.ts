import ChartLoader from './chartLoader';

export default ChartLoader;
