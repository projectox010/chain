import TokenInfoLoader from './tokenInfoLoader';

export default TokenInfoLoader;
