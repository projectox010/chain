import { AssetLoader, StakeLoader } from './walletLoader';

export { AssetLoader, StakeLoader };
