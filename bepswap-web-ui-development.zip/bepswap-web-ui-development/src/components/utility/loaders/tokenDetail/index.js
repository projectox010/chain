import TokenDetailLoader from './tokenDetailLoader';

export default TokenDetailLoader;
