import { Loader } from './pageLoader';

export default Loader;
