import TransactionLoader from './transactionLoader';

export default TransactionLoader;
