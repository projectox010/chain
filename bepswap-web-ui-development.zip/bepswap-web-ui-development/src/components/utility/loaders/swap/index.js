import SwapLoader from './swapLoader';

export default SwapLoader;
