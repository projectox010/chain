import LabelLoader from './labelLoader';

export default LabelLoader;
