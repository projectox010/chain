import styled from 'styled-components';

export const TokenInputWrapper = styled.div``;
