import WebFontLoader from './webfontloader';

export default WebFontLoader;
