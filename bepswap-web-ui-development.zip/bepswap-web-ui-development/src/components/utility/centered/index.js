import Centered from './centered';

export default Centered;
