import ViewPanel from './viewPanel';

export default ViewPanel;
