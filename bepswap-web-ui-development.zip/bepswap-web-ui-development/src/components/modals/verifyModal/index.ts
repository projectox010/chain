import VerifyModal from './verifyModal';

export default VerifyModal;
