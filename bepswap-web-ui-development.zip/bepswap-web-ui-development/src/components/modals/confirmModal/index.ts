import ConfirmModal from './confirmModal';

export default ConfirmModal;
