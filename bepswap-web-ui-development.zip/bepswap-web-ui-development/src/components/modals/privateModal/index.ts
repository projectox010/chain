import PrivateModal from './privateModal';

export default PrivateModal;
