import SlipVerifyModal from './slipVerifyModal';

export default SlipVerifyModal;
